using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ArcherMan : MonoBehaviour
{
    public GameObject arrowPrefab;
    public float coolDown = 2.5f;
    public float timer;
    private DefenderAudio defenderAudio;
    public Transform arrowSpawnPoint; 

    // Start is called before the first frame update
    void Start()
    {
        timer = 0;

        defenderAudio = GetComponent<DefenderAudio>();
    }

    // Update is called once per frame
    void Update()
    {
        // count down based on actual time
        timer -= Time.deltaTime;

        

        if (timer <= 0)
        {
            if (defenderAudio != null)
            {
                defenderAudio.PlayAttackSound();
            }
            // Instantiate include 3 parameter, 1.what are you spawning? 2. where? 3. any special rotation?
            Instantiate(arrowPrefab, arrowSpawnPoint.position, Quaternion.identity);
            timer = coolDown;
        }
        
    }
}
