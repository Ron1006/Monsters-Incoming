using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ArcherStatementMachine : MonoBehaviour
{
    public ArcherState archerState;
    public float detectionRange = 6;
    public LayerMask enemyLayer;
    public ArcherMovement archerMovement;
    public ArcherMan archerMan;

    // Start is called before the first frame update
    void Start()
    {
        archerState = ArcherState.Walking;
        archerMan.enabled = false;
    }

    // Update is called once per frame
    void Update()
    {
        if(archerState == ArcherState.Walking)
        {
            // create a ray include 3 parameater, 1. where from.  2. direction  3. ray length  4. which layer
            RaycastHit2D hit = Physics2D.Raycast(transform.position, Vector2.right, detectionRange, enemyLayer);
            if(hit.collider != null)
            {
                archerState = ArcherState.Shooting;
                archerMan.enabled = true;
                archerMovement.enabled = false;

                // ֹͣ�ƶ�
                archerMovement.archerRb.velocity = Vector2.zero;
            }
            else
            {
                archerMovement.enabled = true;
                archerMan.enabled = false;

                // �ָ��ƶ��ٶ�
                archerMovement.archerRb.velocity = Vector2.right * archerMovement.speed;
            }
        }
        else if (archerState == ArcherState.Shooting)
        {
            // �����״̬ʱ�������������Ƿ񻹴���
            RaycastHit2D hit = Physics2D.Raycast(transform.position, Vector2.right, detectionRange, enemyLayer);
            if (hit.collider == null)
            {
                // ���û�м�⵽���ˣ��ص�����״̬
                archerState = ArcherState.Walking;
                archerMovement.enabled = true;
                archerMan.enabled = false;

                // �ָ��ƶ��ٶ�
                archerMovement.archerRb.velocity = Vector2.right * archerMovement.speed;
            }
        }
    }
}

// enumerations, creates a list of variables that we can choose from
public enum ArcherState
{
    Idle,
    Walking,
    Shooting
};
