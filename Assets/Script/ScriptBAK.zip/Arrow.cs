using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using static UnityEngine.GraphicsBuffer;

public class Arrow : MonoBehaviour
{
    public Rigidbody2D arrowRb;
    public float speed = 5f;
    public float range = 2f;
    private float timer;
    public int damage = 2;
    public float knockbackForce;
    private bool hasHit = false; // ���ڱ���Ƿ������� 

    public BowMan bowMan;

    // Start is called before the first frame update
    void Start()
    {
        if (bowMan != null)
        {
            damage = bowMan.attackPower;
        }
        else
        {
            Debug.Log("no bowman");
        }
        
        timer = range;
    }

    // Update is called 50 times per frame
    void FixedUpdate()
    {


        if (!hasHit) //ֻ��û������ʱ�ż����ƶ�
        {
            arrowRb.velocity = Vector2.right * speed;
        }
        
        timer -= Time.deltaTime;
        if (timer < 0)
        {
            Destroy(gameObject);
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (hasHit) return; // ����Ѿ����У����ٴ����µ���ײ

        if (collision.gameObject.GetComponent<EnemyHealth>())
        {
            // ���Ϊ������
            hasHit = true;

            // �������˻��˺��˺�
            Rigidbody2D enemyRb = collision.gameObject.GetComponent<Rigidbody2D>();
            if (enemyRb != null)
            {
                enemyRb.AddForce(Vector2.right * knockbackForce, ForceMode2D.Impulse);
            }

            collision.gameObject.GetComponent<EnemyHealth>().TakeDamage(damage);

            Destroy(gameObject);
        }

        else if (collision.gameObject.GetComponent<CaveHealth>())
        {
            // ���Ϊ������
            hasHit = true;

            // �Զ�Ѩ����˺�
            collision.gameObject.GetComponent<CaveHealth>().TakeDamage(damage);
            Destroy(gameObject); // ���ټ�ʸ
        }
    }
}
