using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AudioManager : MonoBehaviour
{
    public static AudioManager instance; // ����ģʽ��ȫ��

    public AudioSource audioSource;  // ��ƵԴ
    public AudioClip upgradeButtonSound;  // ������ť��Ч
    public AudioClip clickButtonSound;  // �����ť��Ч

    void Awake()
    {
        // ȷ������ģʽ����ȷ����
        if (instance == null)
        {
            instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }

    public void PlaySound(AudioClip clip)
    {
        if (audioSource != null && clip != null)
        {
            audioSource.PlayOneShot(clip);
        }
        else
        {
            Debug.LogWarning("AudioSource or AudioClip is missing.");
        }
    }

    public void PlayUpgradeButtonSound()
    {
        PlaySound(upgradeButtonSound);
    }

    public void PlayClickButtonSound()
    {
        PlaySound(clickButtonSound);
    }
}

