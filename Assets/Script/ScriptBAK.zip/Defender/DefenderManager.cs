using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using TMPro;

public class DefenderManager : MonoBehaviour
{
    public Defender[] defenders; // �洢���� Defenders ������

    
    //����ĳ��Defender
    public void UpgradeDefender(int defenderIndex)
    {
        if(defenderIndex >= 0 &&  defenderIndex < defenders.Length)
        {
            defenders[defenderIndex].LevelUp();
        }
    }

    // ��ȡ��ǰ���� Defender ��Ϣ
    public void DisplayDefenderInfo()
    {
        foreach (var defender in defenders)
        {
            Debug.Log(defender.name + ": 111111111111111111 " + defender.level + ", attack " + defender.attackPower + ", health " + defender.health);
        }
    }
}
