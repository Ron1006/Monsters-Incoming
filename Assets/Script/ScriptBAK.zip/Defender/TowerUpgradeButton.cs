using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class TowerUpgradeButton : MonoBehaviour
{
    public DisplayTower displayTower;
    public Button upgradeButton;
    public TextMeshProUGUI buttonText; // ��ť����

    // Start is called before the first frame update
    void Start()
    {
        upgradeButton.onClick.AddListener(OnUpgradeButtonClicked);
        UpdateButtonState(); // ��ʼ״̬
    }

    void OnUpgradeButtonClicked()
    {
        displayTower.LevelUp();
        UpdateButtonState(); // �������°�ť״̬
        // ����ȫ�ְ�ť�������
        AudioManager.instance.PlayUpgradeButtonSound();
    }

    private void Update()
    {
        UpdateButtonState(); // ��ʼ״̬
    }

    void UpdateButtonState()
    {
        bool canUpgrade = displayTower != null &&
                          displayTower.level < displayTower.maxLevel &&
                          displayTower.inventoryManager.GetCurrentCoins() >= displayTower.upgradeCost;

        upgradeButton.interactable = canUpgrade;

        if (canUpgrade)
        {
            buttonText.color = Color.white; // ����ʱ�ָ���ɫ
        }
        else
        {
            buttonText.color = Color.red; // ������ʱ��ʾ��ɫ
        }
    }
}
