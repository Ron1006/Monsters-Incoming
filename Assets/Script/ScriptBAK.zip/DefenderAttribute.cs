using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DefenderAttribute : MonoBehaviour
{
    public int cost;
    public Sprite defenderImage;

}
