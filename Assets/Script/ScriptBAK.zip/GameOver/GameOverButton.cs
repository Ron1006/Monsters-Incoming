using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class GameOverButton : MonoBehaviour
{
    public Button closeButton;
    public Button collectX2Button;

    // Start is called before the first frame update
    void Start()
    {
        closeButton.onClick.AddListener(OnCloseClicked);
        collectX2Button.onClick.AddListener(OnCollectClicked);
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void OnCloseClicked()
    {
        SceneManager.LoadScene("MapScene");
    }

    void OnCollectClicked()
    {
        Debug.Log("Watch AD");
    }
}
