using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class MenuButtonManager : MonoBehaviour
{
    public Button attackButton;
    public Button backButton;

    public MoveManToLevel moveManToLevel; // ����MoveManToLevel�ű�

    // Start is called before the first frame update
    void Start()
    {
        attackButton.onClick.AddListener(OnAttackButtonClicked);
        backButton.onClick.AddListener(OnBackButtonClicked);
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnAttackButtonClicked()
    {
        // ��ȡ��ǰѡ�е�Level����
        string currentLevel = moveManToLevel.GetCurrentLevelName();

        if (currentLevel != null )
        {
            currentLevel = "Level1";
        }

        // ���ݵ�ǰLevel���Ƽ�����Ӧ�ĳ���
        switch (currentLevel)
        {
            case "Level1":
                SceneManager.LoadScene("ForestScene");
                break;
            case "Level2":
                SceneManager.LoadScene("ForestScene2");
                break;
            case "Level3":
                SceneManager.LoadScene("ForestScene3");
                break;
            case "Level4":
                SceneManager.LoadScene("ForestScene4");
                break;
            case "Level5":
                SceneManager.LoadScene("ForestScene5");
                break;
            case "Level6":
                SceneManager.LoadScene("ForestScene6");
                break;
            default:
                Debug.LogWarning("No level selected or invalid level.");
                break;
        }
    }

    private void OnBackButtonClicked()
    {
        SceneManager.LoadScene("MenuScene");
    }
}
