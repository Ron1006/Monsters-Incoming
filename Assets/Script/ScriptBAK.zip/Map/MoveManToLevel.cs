using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoveManToLevel : MonoBehaviour
{
    public GameObject man;
    public float moveSpeed = 2f;
    private Vector3 targetPosition; // Target position for the man
    private bool isMoving = false;

    private Transform currentLevel;// ���浱ǰLevel��λ��

    public void MoveToLevel(Transform levelPosition)
    {
        // Set the target position (x, y from level, z = -1)
        targetPosition = new Vector3(levelPosition.position.x, levelPosition.position.y + 0.3f, -1f);
        isMoving = true;

        currentLevel = levelPosition;
    }

    private void Update()
    {
        if (isMoving)
        {
            // Move the man towards the target position smoothly
            man.transform.position = Vector3.MoveTowards(man.transform.position, targetPosition, moveSpeed * Time.deltaTime);

            // If the man has reached the target position, stop moving
            if (Vector3.Distance(man.transform.position, targetPosition) < 0.01f)
            {
                isMoving = false;
            }
        }
    }

    //���ص�ǰѡ�е�Level����
    public string GetCurrentLevelName()
    {
        if (currentLevel !=null)
        {
            return currentLevel.gameObject.name;
        }
        return ""; //û��ѡ���κ�level���ؿ�ֵ
    }
}
