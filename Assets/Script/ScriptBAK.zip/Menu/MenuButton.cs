using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class MenuButton : MonoBehaviour
{
    public Button battleButton;
    public Button upgradeButton;
    public Button editTeamButton;
    public Button back;
    public Button editTeamInUpgradeButton;
    public Canvas upgradeCanvas;
    public Button resetButton;
    public Button showPlayerPrefsButton;
    public Button drawCardSingleButton;
    public Button drawCardsMutipleButton;

    public LotterySystem lotterySystem;

    // Start is called before the first frame update
    void Start()
    {
        upgradeCanvas.enabled = false;
        // �󶨵���¼�����ť
        battleButton.onClick.AddListener(OnBattleClicked);
        upgradeButton.onClick.AddListener(OnUpgradeClicked);
        editTeamButton.onClick.AddListener(OnEditTeamClicked);
        back.onClick.AddListener(OnBackClicked);
        editTeamInUpgradeButton.onClick.AddListener (OnEditTeamInUpgradeClicked);
        resetButton.onClick.AddListener(ResetPlayerPrefs);
        showPlayerPrefsButton.onClick.AddListener(ShowAllPlayerPrefs);
        drawCardSingleButton.onClick.AddListener(OnDrawCardSingleButtonClicked);
        drawCardsMutipleButton.onClick.AddListener(OnDrawCarsMutipleButtonClicked);
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnBattleClicked()
    {
        AudioManager.instance.PlayClickButtonSound();
        SceneManager.LoadScene("MapScene");
    }

    private void OnUpgradeClicked()
    {
        AudioManager.instance.PlayClickButtonSound();
        upgradeCanvas.enabled = true;
    }

    private void OnEditTeamClicked()
    {
        AudioManager.instance.PlayClickButtonSound();
        Debug.Log("Edit Team clicked");
    }

    private void OnEditTeamInUpgradeClicked()
    {
        AudioManager.instance.PlayClickButtonSound();
        Debug.Log("Edit Team clicked");
    }

    private void OnBackClicked()
    {
        AudioManager.instance.PlayClickButtonSound();
        upgradeCanvas.enabled = false;
    }

    void ResetPlayerPrefs()
    {
        PlayerPrefs.DeleteAll();
        PlayerPrefs.Save(); // ȷ��ɾ����������������
        Debug.Log("PlayerPrefs ���������ã�");
    }

    void ShowAllPlayerPrefs()
    {
        Debug.Log("==== PlayerPrefs ���� ====");

        List<string> keys = new List<string> {
        "StickMan_Level",
        "ArcherMan_Level"
        // ���������������ĵ����м�
    };

        foreach (string key in keys)
        {
            if (PlayerPrefs.HasKey(key))
            {
                Debug.Log(key + ": " + PlayerPrefs.GetInt(key));
            }
            else
            {
                Debug.LogWarning(key + " δ�ҵ���");
            }
        }

        Debug.Log("========================");
    }

    private void OnDrawCardSingleButtonClicked()
    {
        lotterySystem.DrawDefender(lotterySystem.drawQuantitySingle, lotterySystem.drawOnceCost);
        
    }

    private void OnDrawCarsMutipleButtonClicked()
    {
        lotterySystem.DrawDefender(lotterySystem.drawQuantityMultiple, lotterySystem.drawMultipleCost);
        
    }
}
