using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemySpawnerRegular : MonoBehaviour
{
    public GameObject[] enemyPrefab;
    public float spawnTime = 2;
    private float timer;
    private int currentEnemy;
    // Start is called before the first frame update
    void Start()
    {
        timer = spawnTime;
    }

    // Update is called once per frame
    void Update()
    {
        timer -= Time.deltaTime;

        if (timer <= 0)
        {
            SpawnEnemy();
        }
    }

    void SpawnEnemy()
    {
        // ������� y �������� 0.5 �� -0.1 ֮��
        float randomY = Random.Range(-0.7f, -0.1f);

        // ����ʱ���� x �� z = y������ y ��
        Vector3 spawnPosition = new Vector3(transform.position.x, randomY, randomY);


        Instantiate(enemyPrefab[currentEnemy], spawnPosition, Quaternion.identity);
        currentEnemy++;
        if (currentEnemy >= enemyPrefab.Length)
        {
            currentEnemy = 0;
        }
        timer = spawnTime;
    }
}
